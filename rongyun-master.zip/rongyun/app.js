const express = require('express');
const path = require('path');
const favicon = require('serve-favicon');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const csrf = require('csurf');

const config = require('./config');
const logger = require('./lib/logger');
const error = require('./lib/error');
const errorHandler = require('./middleware/error/index');

const log = logger(config.log);
const app = express();
//设置全局变量
global.logger = log;
global.config = config;

global.HttpError = error.HttpError;
global.BadRequestError = error.BadRequestError;
global.UnauthorizedError = error.UnauthorizedError;
global.NotFoundError = error.NotFoundError;
global.InternalServerError = error.InternalServerError;

//设置模板引擎
// app.set('views', path.join(__dirname, 'views'));
// app.engine('.html', require('express-art-template'));
// app.set('view options', config.template);
// app.set('view engine', 'html');

app.set('port', config.server.port.http);
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'static')));
//是否开启防止csrf攻击
// app.use(csrf({cookie: true}));

//日志记录
const apilog = require('./middleware/log');
const session = require('./middleware/session');
app.use(apilog());
app.use(session());

//route
const common = require('./routes/common');
const rongyun = require('./routes/rongyun');
const redpack = require('./routes/redpack');
common.map(app);
rongyun.map(app);
redpack.map(app);


//error
app.use(function (err, req, res, next) {
	if (err.code !== 'EBADCSRFTOKEN') return next(err);

	// handle CSRF token errors here
	res.status(403)
	res.send('form tampered with')
});
app.use(errorHandler.notFoundHandler());
app.use(errorHandler.serverErrorHandler());

module.exports = app;
