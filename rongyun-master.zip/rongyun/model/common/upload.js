/**
 * Created by liqp on 2017/11/17.
 */
const bassFile = require('../../server/droi').FILE_CLIENT;

//获取上传token
exports.getToken =async function (file) {
	try {
		let name = file.name;
		let type = file.type;
		let size = file.size;
		let hash = file.hash;

		return await bassFile.create(name, type, size, hash);
	} catch (err){
	    throw err;
	}
};

exports.upload = async function (imgPath, tokenResult) {
	try {
		let url = tokenResult.UploadUrl;
		let token = tokenResult.Token;
		let sessionId = tokenResult.SessionId;
		let id = tokenResult.Id;

		return await bassFile.upload(url, token, sessionId, id, imgPath);
	} catch (err){
	    throw err
	}
};