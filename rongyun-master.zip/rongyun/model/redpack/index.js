/**
 * Created by liqp on 2017/11/23.
 */
const bassObject = require('../../server/droi').OBJECT_CLIENT;

//创建红包
exports.createRedPack = async function (userId, table, num, money, notes, redPacks) {
	try {
		let endTime = new Date(new Date().setHours(new Date().getHours()+24));
		let data = {
			totalMoney: ~~money,
			totalNumber: ~~num,
			userId: userId,
			remainNumber: ~~num,
			remainMoney: ~~money,
			notes: notes,
			endTime: endTime,
			status: 0,
			userRef: {
			    _DataType: "_ReferenceType",
			    _TableName: table,
			    _Id: userId,
			},
		};

		let redPackResult =  await bassObject.create('redpack', data);
		if (redPackResult.Code !== 0) {
			return false;
		}
		let redPackId = redPackResult.Result._Id;

		//筛选最佳手气金额
		let maxMoney = 0;
		redPacks.forEach(function (redPack) {
			if (redPack > maxMoney) {
			    maxMoney = redPack;
			}
		});

		let best = false;
		let infoData = [];
		redPacks.forEach(function (redPack, index) {

			infoData.push({
				redpackId: redPackId,
				money: ~~redPack,
				status: 0,
				endTime: endTime,
				redpackRef: {
				    _DataType: "_ReferenceType",
				    _TableName: "redpack",
				    _Id: redPackId,
				},
				sort: index,
				best: (!best && redPack === maxMoney),
			});
			//标记已有最佳手气
			if (redPack === maxMoney) {
				best = true;
			}
		});

		let infoResult = await bassObject.bulkCreate('redpack_info', infoData);

		if (infoResult.Code === 0) {
		    return redPackId;
		}

		return false;
	} catch (err){
		throw err;
	}

};

//更改红包状态为生效
exports.updateRedPackStatus = async function (id) {
	try {
	    let update = {
	    	status: 1,
		};

		return await bassObject.update('redpack', id, update);
	} catch (err){
		throw err;
	}
};

//获取红包剩余数量
exports.getRemainNumber = async function (id) {
	try {
		return bassObject.selectOne('redpack', id);
	} catch (err){
	    throw err;
	}
};

//获取红包领取详情
exports.redPackInfo = async function (id) {
	try {
		let condition = {
			where: {
				redpackId: id,
				status: 1,
			}
		};

		return await bassObject.select('redpack_info', condition);
	} catch (err){
	    throw err;
	}
};


//二次密码校验
exports.checkPWD = async function (userId, userType, password) {
	try {
		return bassObject.checkPassword(userId, userType, password);
	} catch (err){
	    throw err;
	}
};

//发红包扣款接口
exports.redPackCharge = async function (userId, money, userType, redPackId) {
	try {
		return bassObject.sendRedPack(userId, money, userType, redPackId);
	} catch (err){
		throw err;
	}
};

//用户领取红包接口
exports.receiveRed = async function (redpackId, sendUserId, sendUserType, receiveUserId, receiveUserType, sort) {
	try {
		let table = receiveUserType === 0 ? 'show_trader' : 'show_member';
		let condition = {
			limit: 1,
			where: {
				redpackId: redpackId,
				status: 0,
				sort: sort,
			}
		};

		//获取红包数据
		let res = await bassObject.select('redpack_info', condition);
		if (res.Code !== 0 || res.Count === 0) {
		    return false;
		}

		let money = res.Result[0].money;
		let redPackInfoId = res.Result[0]._Id;
		let update = {
			userId: receiveUserId,
			userRef: {
			    _DataType: "_ReferenceType",
			    _TableName: table,
			    _Id: receiveUserId,
			},
			status: 1,
			remitteeTime: new Date(),
		};

		//更新用户信息到红包详情表
		let updateResult = await bassObject.update('redpack_info', redPackInfoId, update);
		if (updateResult.Code !== 0) {
		    return false;
		}

		//更新红包剩余数据
		let updateNum = {
			remainNumber: {
			    __op: "Increment",
			    amount: -1
			},
			remainMoney: {
			    __op: "Increment",
			    amount: -money
			}
		};
		let numResult = await bassObject.update('redpack', redpackId, updateNum);
		if (numResult.Code !== 0) {
			return false;
		}

		//调取踊跃接口改变金额
		let addMoney = await bassObject.receiveRedPack(sendUserId, sendUserType, money/100 ,receiveUserId, receiveUserType, redPackInfoId);
		if (addMoney.Code !== 0 || addMoney.Result.errorCode !== 0) {
			console.error(addMoney);
			return false;
		}

		return money;
	} catch (err){
	    throw err;
	}
};
