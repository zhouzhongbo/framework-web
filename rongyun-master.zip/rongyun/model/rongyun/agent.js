/**
 * Created by liqp on 2017/12/20.
 */
const request = require('request');
const superagent = require( 'superagent' );
const sha1 = require('sha1');
const fs = require('fs');
const path = require('path');
let userid = 102985;

function header() {
	let APPSECRET = config.rongyunAgent.secret;
	let NONCE = parseInt( Math.random() * 0xffffff );
	let TIMESTAMP = Date.parse( new Date() )/1000;
	return rongyunHeader = {
		'App-Key': config.rongyunAgent.key,
		'Nonce': NONCE,
		'Timestamp': TIMESTAMP,
		'Signature': sha1( APPSECRET + NONCE + TIMESTAMP  ),
		'Content-Type': 'application/x-www-form-urlencoded',
	};
}

exports.addAgent = function (traderId, callback) {
	let url = `shop${traderId}/production.p12`;
	// 下载证书
	let optionP12 = {
		url: `http://bestshowu.com:8053/api/v3/projects/28/repository/files/${encodeURIComponent(url)}/raw?ref=master`,
		headers: {
			"PRIVATE-TOKEN": 'H7ejvGecDWkzxb2DMr8y'
		},
		json: true,
		method: 'GET',
	};

	let writePath = path.join(process.cwd(), `/static/${traderId}.p12`);
	let writeStream = fs.createWriteStream(writePath);

	let req = request(optionP12);
	req.pipe(writeStream);
	req.on('end', function () {
		writeStream.on('finish', function () {
			//上传证书到融云创建应用标识
			// let APPSECRET = config.rongyunAgent.secret;
			// let NONCE = parseInt( Math.random() * 0xffffff );
			// let TIMESTAMP = Date.parse( new Date() )/1000;
			// let rongyunHeader = {
			// 	'App-Key': config.rongyunAgent.key,
			// 	'Nonce': NONCE,
			// 	'Timestamp': TIMESTAMP,
			// 	'Signature': sha1( APPSECRET + NONCE + TIMESTAMP  ),
			// 	'Content-Type': 'application/x-www-form-urlencoded',
			// };

			let rongyunHeader = header();
			let option = {
				url: 'http://api.developer.rongcloud.cn/appInte/saveIdentifier.json',
				method: 'POST',
				headers: rongyunHeader,
				formData: {
					'app_key': config.rongyun.key,
					'package_name': `com.showu.shop${traderId}`,
					'bundle_id': `com.showu.shop${traderId}`,
					'productionPassword': '',
					'file_product': fs.createReadStream(writePath)
				},
				json: true
			};

			request(option, function (err, code, res) {
				fs.unlinkSync(writePath);
				callback(err, res)
			})
		});

	});
};

exports.addUser = function (name, phone, email, userId, callback) {
	let rongyunHeader = header();
	let option = {
		url: 'http://api.developer.rongcloud.cn/user/create.josn',
		method: 'POST',
		headers: rongyunHeader,
		form: {
			'userid': userId,
			'name': name,
			'email': email,
			'mobile': phone,
		},
		json: true
	};

	request(option, function (err, code, res) {
		console.log(res);
		callback(err, res);
	})
};

exports.createApp = function (name, description, callback) {
	let rongyunHeader = header();
	let option = {
		url: 'http://api.developer.rongcloud.cn/app/createApp.json',
		method: 'POST',
		headers: rongyunHeader,
		form: {
			'userId': userid,
			'name': name,
			'category': 10,
			'description': description,
		},
		json: true
	};

	console.log(option);
	request(option, function (err, code, res) {
		console.log(res);
		callback(err, res);
	})
};

exports.removeApp = function (name, callback) {
	let rongyunHeader = header();
	let option = {
		url: 'http://api.developer.rongcloud.cn/app/getAppIdentifierInfo',
		method: 'POST',
		headers: rongyunHeader,
		form: {
			'userId': userid,
			'appName': name,
		},
		json: true
	};

	request(option, function (err, code, res) {
		console.log(res);
		callback(err, res);
	})
};
