/**
 * Created by liqp on 2017/11/10.
 */

const bassObject = require('../../server/droi').OBJECT_CLIENT;

//获取用户信息
exports.getUserInfoForToken = async function (accessToken) {
	try {
		let condition = {
			where: {
				accessToken: accessToken,
				accessTokenExpiresAt: {$gt: new Date().getTime()}
			}
		};

		return await bassObject.select('oauth_token', condition);
	} catch (err){
	    throw err;
	}
};

//获取用户信息
exports.getUserInfoForId = async function (table, userId) {
	try {
		return await bassObject.selectOne(table, userId);
	} catch (err){
		throw err;
	}

};

//创建用户token
exports.createUserToken = async function (userId, token, table) {
	try {
		let update = {
			rongyuntoken: token,
		};

		return await  bassObject.update(table, userId, update)
	} catch (err){
	    throw err;
	}

};

//修改用户当前登录状态
exports.updateUserStatus = async function (userId, status) {
	try{
		let update = {
			status: status
		};

		return await bassObject.update('user', userId, update);
	} catch (err){
		throw err;
	}

};

//检查用户关系
exports.checkRelation = async function (userId, toUserId) {
	try {
		let condition = {
			where: {
				userId: userId,
				toUserId: toUserId
			}
		};

		return await bassObject.select('social_relation', condition);
	} catch (err){
	 	throw err;
	}
};

//添加好友(用户对用户)
exports.addUserToUserRelation = async function (userId, toUserId) {
	try {
		let data = {
			userId: userId,
			toUserId: toUserId,
			toUserRef: {
				_DataType: "_ReferenceType",
				_TableName: 'show_member',
				_Id: toUserId,
			},
		};

		return await bassObject.create('social_relation', data);
	} catch (err){
	    throw err;
	}
};

//添加好友(用户对用户)
exports.addUserToTraderRelation = async function (userId, toUserId, toTrader) {
	try {
		let table = 'show_member';
		if (toTrader) {
			table = 'show_trader'
		}

		let data = {
			userId: userId,
			toUserId: toUserId,
			toUserRef: {
				_DataType: "_ReferenceType",
				_TableName: table,
				_Id: toUserId,
			},
		};


		return await bassObject.create('social_relation', data);
	} catch (err){
		throw err;
	}
};

//获取好友信息
exports.getFriendsInfo = async function (userId) {
	try {
		let condition = {
			where:{
				userId: userId,
			},
		};

		return await bassObject.select('social_relation', condition);
	} catch (err){
	    throw err
	}
};

//删除好友
exports.delUserRelation = async function (userId, toUserId) {
	try {
		let condition = {
			where: {
				userId: userId,
				toUserId: toUserId
			}
		};

		let relation = await bassObject.select('social_relation', condition);
		if (relation.Result.length>0) {
			let id = relation.Result[0]._Id;
			return await bassObject.del('social_relation', id);
		} else {
			return false;
		}
	} catch (err){
	    throw err;
	}

};

//修改关系中的备注昵称
exports.updateRelation = async function (id, nickname) {
	try {
	    let update = {
	    	nickname: nickname
		};

		return await bassObject.update('social_relation', id, update);
	} catch (err){
	    throw err;
	}
};

//批量获取好友信息
exports.getFriendsBulk = async function (userId, toUserIds) {
	try {
		let condition = {
			limit: 1000,
			where: {
				userId: userId,
				toUserId: {$in: toUserIds}
			}
		};

		return await bassObject.select('social_relation', condition);
	} catch (err){
	    throw err;
	}
};

//===============================群关系====================================================================

//获取用户的群
exports.getGroupForUser = async function (userId) {
	try {
	    let condition = {
	    	where: {
	    		userId: userId
			}
		};

	    return await bassObject.select('social_group_relation', condition);
	} catch (err){
	    throw err;
	}
};

//创建群组
exports.createGroup = async function (userId, name, headPic) {
	try {
	    let data = {
	    	userId: userId,
			groupName: name,
			number: 0,
			headpic: headPic
		};

		return bassObject.create('social_group', data);
	} catch (err){
	    throw err
	}
};

//添加群成员
exports.addUserToGroup = async function (userId, groupId, type) {
	try {
		let table = 'show_member';
		if (type === 1) {
			table = 'show_trader'
		}
		
	    let data = {
	    	userId: userId,
			groupId: groupId,
			type: type,
			userRef: {
				_DataType: "_ReferenceType",
				_TableName: table,
				_Id: userId,
			},
			groupRef: {
				_DataType: "_ReferenceType",
				_TableName: "social_group",
				_Id: groupId,
			},
		};
		
		let groupUpdate = {
	    	number: {
	    	    __op: "Increment",
	    	    amount: +1
	    	}
		};


		// let update = {
		// 	userRef: {
		// 	    _DataType: "_ReferenceType",
		// 	    _TableName: table,
		// 	    _Id: userId,
		// 	},
		// 	groupRef: {
		// 	    _DataType: "_ReferenceType",
		// 	    _TableName: "social_group",
		// 	    _Id: groupId,
		// 	},
		// };

		let condition = {
			where: {
				groupId: groupId,
				userId: userId
			}
		};

		//判断此人是否已经在群中
		let relation = await bassObject.select('social_group_relation', condition);
		if (relation.Count > 0) {
		    return true
		}

		let createResult = await bassObject.create('social_group_relation', data);
		if (createResult && createResult.Code === 0) {
			// let relationId = createResult.Result._Id;
			// await bassObject.update('social_group_relation', relationId, update);
			await bassObject.update('social_group', groupId, groupUpdate);

			return true;
		}else {
			return false;
		}
	} catch (err){
	    throw err;
	}
};

//删除群成员
exports.delUserFromGroup = async function (userId, groupId) {
	try {
		let condition = {
			where: {
				userId: userId,
				groupId: groupId
			}
		};

		let groupUpdate = {
			number: {
				__op: "Increment",
				amount: -1,
			}
		};

		let result = await bassObject.select('social_group_relation', condition);
		if (result.Result.length>0) {
			let id = result.Result[0]._Id;
			await bassObject.update('social_group', groupId, groupUpdate);
			await bassObject.del('social_group_relation', id);
			return true;
		} else {
			return true;
		}
	} catch (err){
	    throw err;
	}

};

//查询群信息
exports.getGroupInfo = async function (groupId) {
	try {
	    return await bassObject.selectOne('social_group', groupId);
	} catch (err){
	    throw err;
	}
};

//解散群
exports.delGroup = async function (groupId) {
	try {
		let condition = {
			keys: '_Id',
			where: {
				groupId: groupId
			}
		};

		let relationIds = [];
		let ids = await bassObject.select('social_group_relation', condition);

		ids.Result.forEach(function (id) {
			relationIds.push(id._Id)
		});

		await bassObject.del('social_group', groupId);
		await bassObject.bulkDel('social_group_relation', relationIds);
		return true;
	} catch (err){
	    throw err;
	}

};

//查询群成员信息
exports.getGroupUser = async function (groupId) {
	try {
		let condition = {
			where: {
				groupId: groupId
			}
		};

		return await bassObject.select('social_group_relation', condition);
	} catch (err){
	    throw err;
	}
};

//修改群公告
exports.updateNotes = async function (groupId, notes) {
	try {
	    let update = {
	    	notes: notes,
			notesTime: new Date(),
		};

		return bassObject.update('social_group', groupId, update)
	} catch (err){
	    throw err;
	}
};

//修改群信息
exports.updateGroup = async function (groupId, groupName, headPic) {
	try {
		let update = {};

		if (groupName) {
		    update.groupName = groupName;
		}

		if (headPic) {
			update.headpic = headPic;
		}

		return bassObject.update('social_group', groupId, update)
	} catch (err){
		throw err;
	}
};

//修改自己在群中的昵称
exports.updateGroupNickname = async function (userId, groupId, nickname) {
	try {
	    let condition = {
	    	where: {
				userId: userId,
				groupId: groupId,
			}
		};

	    let update = {
			nickname: nickname
		};

		let res = await bassObject.select('social_group_relation', condition);
		if (res.Code !== 0 || res.Count === 0) {
		    return false;
		}

		let id = res.Result[0]._Id;

		let updateNickname = await bassObject.update('social_group_relation', id, update);

		return updateNickname.Code === 0;
	} catch (err){
	    throw err;
	}
};