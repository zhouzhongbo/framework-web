/**
 * @author logoli on 2017/11/10
 * @copyright
 * @desc
 */
const util = require('util');
const UserModel = require('../../model/rongyun/user');
/**
 * 对session参数进行处理
 * */
module.exports = function () {
	return async function (req, res, next) {

		req.session = null;

		if (req.path === '/agent') {
		    return next();
		}
		if (process.env.NODE_ENV === 'dev') {
			req.session = {
				user: {
					_Id: '5a1514cc30c6a10015000002',
					_TableName: 'show_trader'
				}
			};

			return next();
		}
		let token = req.get('accessToken');

		token = token ? token.trim() : null;

		//没有token未登录,根据业务修改未登录操作
		if (!token) {
			res.status(401);
			return res.json({
				"error": "invalid_token",
				"error_description": "Invalid token: access token is invalid"
			})
		}
		/*
		 * @desc 用token换session进行后续操作
		 * */
		let userInfo = await UserModel.getUserInfoForToken(token);
		if (userInfo.Code === 0 && userInfo.Count > 0) {
			req.session = userInfo.Result[0];
		}

		if (!req.session) {
			res.status(401);
			return res.json({
				"error": "invalid_token",
				"error_description": "Invalid token: access token is invalid"
			})
		}
		next();
	}
};