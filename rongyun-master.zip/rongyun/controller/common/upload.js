/**
 * Created by liqp on 2017/11/17.
 */
const path = require('path');
const fs = require('fs');
const formidable = require('formidable');

const uploadModel = require('../../model/common/upload');

exports.formUpload = async function (req, res, next) {
	try {
		let obj = {
			status: 0,
			msg: ''
		};

		//获得实例，进行配置
		let form = new formidable.IncomingForm();
		form.hash = 'md5';
		form.uploadDir = path.join(process.cwd(),'static/img');

		//将parse方法转换成promis方法并执行
		let parsePromise = new Promise(function (resolve, reject) {
			form.parse(req, function (err, fields, files) {
				if (!err) {
					resolve({
						fields: fields,
						files: files
					})
				}else {
					reject(err)
				}


			})
		});
		let fileInfo = await parsePromise;

		//取出上传成功后的结果
		let file = fileInfo.files[Object.keys(fileInfo.files)[0]];
		let imgPath = file.path;

		//获取上传token
		let result = await uploadModel.getToken(file);
		if (result.Code === 0) {
			let tokenResult = result.Result;

			//进行文件上传
			let uploadResult = await uploadModel.upload(imgPath, tokenResult);
			if (uploadResult.Code === 0) {
				obj.result = uploadResult.Result;
			}
		}

		//删除本地文件
		fs.unlinkSync(imgPath);

		res.json(obj)
	} catch (err){
	    next(err);
	}
};