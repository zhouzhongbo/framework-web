/**
 * Created by liqp on 2017/12/20.
 */
const util = require('util');
const AgentModel = require('../../model/rongyun/agent');

exports.addAgent = async function (req, res, next) {
	try {
		let traderId = req.body.traderId;
		if (!traderId) {
		    return next(new BadRequestError('traderId is need'))
		}

		let add = util.promisify(AgentModel.addAgent);
	    let result = await add(traderId);
	    res.json(result)
	} catch (err){
	    next(err);
	}
};
