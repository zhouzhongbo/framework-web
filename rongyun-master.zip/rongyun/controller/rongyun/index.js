/**
 * Created by liqp on 2017/11/10.
 */
const util = require('util');
const UserModel = require('../../model/rongyun/user');
const Cry = require('../../lib/crypto');

const rongcloudSDK = require('rongcloud-sdk');
rongcloudSDK.init(config.rongyun.key, config.rongyun.secret);

const User = rongcloudSDK.user;
const Message = rongcloudSDK.message;
const Group = rongcloudSDK.group;
const key = 'droi';
//用户获取融云token
exports.getToken = async function (req, res, next) {
	try {
		if (req.session.user._Object.rongyuntoken && !req.query.reread) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: true,
					failed_message: '',
					success_message: '',
					userId: req.session.user._Id,
					token: Cry.des(req.session.user._Object.rongyuntoken, key),
				}
			})
		}

		let userId = req.session.user._Id;
		let table = req.session.user._TableName;
		let name = req.session.user.nickname || '默认名字';
		let avatar = req.session.user.headpic || 'http://ouu5ea0z4.bkt.clouddn.com/category/nodejs.png';

		let getToken = util.promisify(User.getToken);
		let result = await getToken(userId, name, avatar);

		let token = JSON.parse(result).token;

		await UserModel.createUserToken(userId, Cry.ces(token, key), table);
		return res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				userId: req.session.user._Id,
				token: req.session.user._Object.rongyuntoken || token,
			}
		})
	} catch (err) {
		next(err)
	}
};

//发送添加好友邀请（用户对用户）
exports.inviteUserToUser = async function (req, res, next) {
	//只发送用户加用户的请求
	try {
		let userId = req.session.user._Id;
		let toUserId = req.body.toUserId;
		let userTraderId = req.session.user._Object.traderid;

		if (!toUserId) {
			return next(new BadRequestError('toUserId is need'));
		}

		if (userId === toUserId) {
			return next(new BadRequestError('userId and toUserId is same'))
		}


		//判断两人是否已经是好友关系
		let relation = await UserModel.checkRelation(userId, toUserId);

		if (relation.Count > 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '你们已经是好友'
				}
			});
		}

		//获取对方的信息
		let toUserInfo = await UserModel.getUserInfoForId('show_member', toUserId);
		if (toUserInfo.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '对方不存在'
				}
			});
		}
		let toUserTraderId = toUserInfo.Result[0].traderid;

		//验证是否在同一商家下
		if (userTraderId !== toUserTraderId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '未在同一平台，不能发送好友邀请'
				}
			});
		}

		let content = {
			operation: "op1",
			sourceUserId: userId,
			targetUserId: toUserId,
			message: "加你为好友",
			user: {
				id: userId,
				name: req.session.user._Object.nickname,
				icon: req.session.user._Object.headpic
			},
			extra: "加你为好友"
		};

		let toUsers = [toUserId];
		let publish = util.promisify(Message.system.publish);
		await publish(userId, toUsers, 'RC:ContactNtf', JSON.stringify(content));

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '好友邀请发送成功',
			}
		});
	} catch (err) {
		next(err)
	}
};

//处理好友邀请（用户对用户）
exports.createUserToUserRelation = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let toUserId = req.body.toUserId;
		let agree = req.body.agree; //RC:InfoNtf
		let userTraderId = req.session.user._Object.traderid;
		let content = {
			message: null,
			extra: null
		};

		if (!userId || !toUserId || !agree) {
			return next(new BadRequestError('userId and toUserId and agree is need'))
		}
		if (userId === toUserId) {
			return next(new BadRequestError('userId and toUserId is same'))
		}

		//判断两人是否已经是好友关系
		let relation = await UserModel.checkRelation(userId, toUserId);

		if (relation.Count > 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '你们已经是好友',
					success_message: '',
				}
			});
		}
		let toUserInfo = await UserModel.getUserInfoForId('show_member', toUserId);

		if (toUserInfo.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '对方不存在',
					success_message: '',
				}
			})
		}

		let toUserTraderId = toUserInfo.Result[0].traderid;

		//验证是否在同一商家下
		if (userTraderId !== toUserTraderId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '未在同一平台，不能发送好友邀请',
					success_message: '',
				}
			})
		}
		if (agree === 'true') {
			await UserModel.addUserToUserRelation(userId, toUserId);
			await UserModel.addUserToUserRelation(toUserId, userId);

			content.message = `${req.session.user._Object.nickname}同意了你的邀请好友请求`;
			content.extra = {
				userId: req.session.user._Id,
				nickname: req.session.user._Object.nickname,
				avatar: req.session.user._Object.headpic
			}
		} else {
			content.message = `${req.session.user._Object.nickname}拒绝了你的邀请好友请求`;
		}

		let publish = util.promisify(Message.private.publish);
		await publish(userId, toUserId, 'RC:InfoNtf', JSON.stringify(content));

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '处理好友邀请成功',
			}
		})
	} catch (err) {
		next(err)
	}

};

//处理好友请求（商家对用户）
exports.createTraderToUserRelation = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let traderId = req.body.traderId;
		let userTraderId = req.session.user._Object.traderid;

		if (!userId || !traderId) {
			return next(new BadRequestError('userId and traderId  is need'))
		}

		if (traderId !== userTraderId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '未在同一平台，不能发送好友邀请',
					success_message: '',
				}
			})
		}

		//判断两人是否已经是好友关系
		let relation = await UserModel.checkRelation(userId, traderId);

		if (relation.Count > 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '你们已经是好友',
					success_message: '',
				}
			});
		}

		await UserModel.addUserToTraderRelation(userId, traderId, true);
		await UserModel.addUserToTraderRelation(traderId, userId);

		let content = {
			name: 'add',
			data: {
				userId: userId,
				nickname: req.session.user._Object.nickname,
				avatar: req.session.user._Object.headpic,
			}
		};
		let publish = util.promisify(Message.system.publish);
		await publish(userId, [traderId], 'RC:CmdMsg', JSON.stringify(content));
		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '处理好友邀请成功',
			}
		})
	} catch (err) {
		next(err)
	}
};

//获取好友列表
exports.getFriends = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;

		let result = await UserModel.getFriendsInfo(userId);
		let users = result.Result;

		let friends = [];
		users.forEach(function (user) {
			friends.push({
				socialId: user._Id,
				userId: user.toUserId,
				nickname: user.toUserRef._Object.nickname || '',
				friendRemark: user.nickname || '',
				sex: user.toUserRef._Object.sex || 0,
				address: user.toUserRef._Object.address || '',
				avatar: user.toUserRef._Object.headpic || '',
				userType: user.toUserRef._TableName === 'show_trader' ? 0 : 1,
			})
		});

		res.json({
			flag: '0000',
			msg: 'ok',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				list: friends
			}
		})
	} catch (err) {
		next(err)
	}

};

//删除好友
exports.delFriend = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let toUserId = req.query.toUserId;

		if (!toUserId) {
			return next(new BadRequestError('toUserId is need'));
		}

		let resultOne = UserModel.delUserRelation(userId, toUserId);
		let resultTwo = UserModel.delUserRelation(toUserId, userId);

		if (resultOne && resultTwo) {
			let content = {
				name: 'delete',
				data: {
					userId: userId,
				}
			};
			let publish = util.promisify(Message.system.publish);
			await publish(userId, [toUserId], 'RC:CmdMsg', JSON.stringify(content));

			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: true,
					failed_message: '',
					success_message: '删除好友成功',
				}
			});
		}

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: false,
				failed_message: '删除好友失败',
				success_message: '',
			}
		});
	} catch (err) {
		next(err)
	}
};

//获取用户信息
exports.getUserInfo = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let toUserId = req.query.userId;
		let type = req.query.type;
		let table;
		if (!toUserId || !type) {
			return next(new BadRequestError('userId and type is need'));
		}
		if (type != 1 && type != 0) {
			return next(new BadRequestError('type is number and eq:1 or 0'));
		}

		if (type == 0) {
			table = 'show_trader'
		} else {
			table = 'show_member'
		}

		let userInfo = await UserModel.getUserInfoForId(table, toUserId);

		let relation = await UserModel.checkRelation(userId, toUserId);
		if (userInfo.Code !== 0 || userInfo.Count === 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '该用户不存在',
					success_message: ''
				}
			})
		}

		let data = {
			ok: true,
			failed_message: '',
			success_message: '',
			is_friend: relation.Code === 0 && relation.Count > 0,
			relationId: relation.Count > 0 ? relation.Result[0]._Id : '',
			avatar: userInfo.Result[0].headpic || '',
			nickname: userInfo.Result[0].nickname || '',
			friendRemark: relation.Count > 0 ? (relation.Result[0].nickname || '') : '',
			sex: userInfo.Result[0].sex || 1,
			address: userInfo.Result[0].address || '',
		};
		res.json({
			flag: '0000',
			msg: '',
			result: data
		})
	} catch (err) {
		next(err);
	}
};

//修改备注昵称
exports.updateNickname = async function (req, res, next) {
	try {
		let relationId = req.body.relationId;
		let nickname = req.body.nickname;

		if (!relationId || !nickname) {
			return next(new BadRequestError('relationId and nickname is need'));
		}

		let result = await UserModel.updateRelation(relationId, nickname);

		if (result.Code === 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: true,
					failed_message: '',
					success_message: '修改成功',
				}
			})
		}

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: false,
				failed_message: '修改失败',
				success_message: '',
			}
		})
	} catch (err) {
		next(err);
	}
};

//===============================群关系====================================================================

//获取群列表
exports.getGroups = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;

		let groups = await UserModel.getGroupForUser(userId);

		if (groups.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '未找到群',
					success_message: ''
				}
			})
		}

		let result = [];

		groups.Result.forEach(function (group) {
			result.push({
				id: group.groupId,
				groupName: group.groupRef._Object.groupName,
				avatar: group.groupRef._Object.headpic || '',
				userId: group.groupRef._Object.userId,
			})
		});
		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				list: result
			}
		})
	} catch (err) {
		next(err);
	}
};

//创建群
exports.createGroup = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let userType = req.session.user._TableName;
		let groupName = req.body.groupName;
		let headPic = req.body.headPic;

		if (!groupName) {
			return next(new BadRequestError('groupName is need'));
		}


		if (userType !== 'show_trader') {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '没有创建权限'
				}
			})
		}

		let result = await UserModel.createGroup(userId, groupName, headPic);
		let groupId = result.Result._Id;

		let create = util.promisify(Group.create);
		let resultRong = await create(userId, groupId, groupName);

		if (JSON.parse(resultRong).code === 200) {
			let update = await UserModel.addUserToGroup(userId, groupId, 1);
			if (update) {
				return res.json({
					flag: '0000',
					msg: '',
					result: {
						ok: true,
						failed_message: '',
						success_message: '',
						groupId: groupId,
						groupName: groupName
					}
				})
			}
			res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '创建失败'
				}
			})
		} else {
			res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '创建失败'
				}
			})
		}
	} catch (err) {
		next(err)
	}
};

//加入群
exports.addGroup = async function (req, res, next) {
	try {
		let isMy = req.body.isMy;
		let userId = req.body.userId;
		let groupId = req.body.groupId;
		let groupName = req.body.groupName;
		let nicknames = req.body.nicknames;
		let operationNickName = req.body.operationNickName;

		if (!isMy || !groupId || !groupName || !nicknames || !operationNickName) {
			return next(new BadRequestError('isMy and groupId and groupName and nicknames and operationNickName is need'))
		}

		if (isMy === 'true') {
			userId = req.session.user._Id
		} else {
			userId = userId.split(',');
		}

		//判断该群是否存在
		let groupInfo = await UserModel.getGroupInfo(groupId);
		if (groupInfo.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '不存在该群'
				}
			});
		}

		if (Array.isArray(userId)) {
			//批量加群操作
			let join = util.promisify(Group.join);
			let resultRong = await join(userId, groupId, groupName);

			if (JSON.parse(resultRong).code == 200) {
				for (let id of userId) {
					await UserModel.addUserToGroup(id, groupId, 0);
				}

				let content = {
					operatorUserId: req.session.user._Id,
					operation: "Add",
					data: {operatorNickname: operationNickName, targetUserIds: userId, targetUserDisplayNames: nicknames.split(',')},
					message: "添加群成员",
					extra: "add"
				};
				let publish = util.promisify(Message.group.publish);
				await publish(req.session.user._Id, groupId, 'RC:GrpNtf', JSON.stringify(content));
				// let content = {"message": `${operationNickName} 邀请 ${nicknames}加入群聊`, "extra": "add"};
				// let publish = util.promisify(Message.group.publish);
				// await publish(req.session.user._Id, groupId, 'RC:InfoNtf', JSON.stringify(content));

				res.json({
					flag: '0000',
					msg: '',
					result: {
						ok: true,
						failed_message: '',
						success_message: '加入成功'
					}
				})
			} else {
				res.json({
					flag: '0000',
					msg: '',
					result: {
						ok: false,
						failed_message: '加入失败'
					}
				})
			}
		} else {
			let join = util.promisify(Group.join);
			let resultRong = await join(userId, groupId, groupName);

			if (JSON.parse(resultRong).code === 200) {
				let update = await UserModel.addUserToGroup(userId, groupId, 0);
				if (update) {
					//往群里发送消息告诉有新人加入
					let content = {
						operatorUserId: req.session.user._Id,
						operation: "Add",
						data: {operatorNickname: operationNickName, targetUserIds: [userId], targetUserDisplayNames: nicknames.split(',')},
						message: "添加群成员",
						extra: "add"
					};
					let publish = util.promisify(Message.group.publish);
					await publish(req.session.user._Id, groupId, 'RC:GrpNtf', JSON.stringify(content));
					// let content = {"message": `${operationNickName} 邀请 ${nicknames}加入群聊`, "extra": "add"};
					// let publish = util.promisify(Message.group.publish);
					// await publish(req.session.user._Id, groupId, 'RC:InfoNtf', JSON.stringify(content));

					res.json({
						flag: '0000',
						msg: '',
						result: {
							ok: true,
							failed_message: '',
							success_message: '加入成功'
						}
					})
				} else {
					res.json({
						flag: '0000',
						msg: '',
						result: {
							ok: false,
							failed_message: '加入失败'
						}
					})
				}
			} else {
				res.json({
					flag: '0000',
					msg: '',
					result: {
						ok: false,
						failed_message: '加入失败'
					}
				})
			}
		}
	} catch (err) {
		next(err)
	}
};

//查询群成员
exports.getGroupInfo = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let groupId = req.query.groupId;

		if (!groupId) {
			return next(new BadRequestError('groupId is need'));
		}

		//获取群成员
		let groupUser = await UserModel.getGroupUser(groupId);
		//获取群信息
		let groupInfo = await UserModel.getGroupInfo(groupId);

		if (groupInfo.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '不存在该群'
				}
			})
		}

		let toUserIds = [];				//群成员id
		let usersObject = {};			//群成员信息对象

		let notesAvatar;				//群公告发布者头像
		let notesNickname;				//群公告发布者昵称
		let notesUserId;				//群公告发布者id
		groupUser.Result.forEach(function (user) {
			toUserIds.push(user.userRef._Id);
			if (user.type === 1) {
				notesUserId = user.userRef._Id;
				notesAvatar = user.userRef._Object.headpic || '';
				notesNickname = user.nickname || user.userRef._Object.nickname || '';
			}
			usersObject[user.userRef._Id] = {
				avatar: user.userRef._Object.headpic || '',
				nickname: user.userRef._Object.nickname || '',
				groupRemark: user.nickname || '',
				userId: user.userRef._Id,
				userType: user.userRef._TableName === 'show_trader' ? 0 : 1,
				is_friend: false,
				socialId: '',
				friendRemark: '',
				sex: 0,
				address: '',
			};
		});

		//查询群成员和用户关系
		let relationResult = await UserModel.getFriendsBulk(userId, toUserIds);
		if (relationResult.Code === 0) {
			relationResult.Result.forEach(function (item) {
				if (item._Id === notesUserId && item.nickname) {		//如果对群主设置了昵称
					notesNickname = item.nickname;
				}
				if (usersObject[item.toUserId]) {
					usersObject[item.toUserId].is_friend = true;
					usersObject[item.toUserId].socialId = item._Id;
					usersObject[item.toUserId].friendRemark = item.nickname || '';
					usersObject[item.toUserId].sex = item.toUserRef._Object.sex || 0;
					usersObject[item.toUserId].address = item.toUserRef._Object.address || '';
				}
			})
		}

		let users = [];
		for (let key in usersObject) {
			users.push(usersObject[key])
		}

		let result = {
			ok: true,
			failed_message: '',
			success_message: '',
			groupId: groupId,
			groupName: groupInfo.Result[0].groupName,
			groupNumber: groupInfo.Result[0].number,
			groupNotes: groupInfo.Result[0].notes || '',
			notesUserAvatar: notesAvatar,
			notesUserNickname: notesNickname,
			notesUserId: notesUserId,
			notesTime: groupInfo.Result[0].notesTime ? new Date(groupInfo.Result[0].notesTime).getTime() : '',
			groupAvatar: groupInfo.Result[0].headpic || '',
			users: users,
		};


		res.json({
			flag: '0000',
			msg: '',
			result: result
		})
	} catch (err) {
		next(err);
	}
};

//修改群公告
exports.updateGroupNote = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let operationNickName = req.body.operationNickName;
		let groupId = req.body.groupId;
		let notes = req.body.notes;

		if (!groupId || !notes || !operationNickName) {
			return next(new BadRequestError('notes and groupId and operationNickName is need'));
		}

		let groupInfo = await UserModel.getGroupInfo(groupId);
		if (!groupInfo || groupInfo.Count === 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '不存在该群'
				}
			})
		}

		//验证该用户是否有权限
		let ownUserId = groupInfo.Result[0].userId;
		if (ownUserId !== userId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '没有修改的权限'
				}
			})
		}

		let result = await UserModel.updateNotes(groupId, notes);
		if (result.Code === 0) {
			//往群聊发送通知
			let content = {"message": `${operationNickName} 修改了群公告`, "extra": "updateGroupNotes"};
			let publish = util.promisify(Message.group.publish);
			await publish(req.session.user._Id, groupId, 'RC:InfoNtf', JSON.stringify(content));

			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: true,
					failed_message: '',
					success_message: '修改成功',
					notesTime: new Date().getTime(),
				}
			})
		}

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: false,
				failed_message: '修改失败',
				success_message: '',
			}
		})
	} catch (err) {
		next(err);
	}
};

//修改群名称
exports.updateGroupInfo = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let operationNickName = req.body.operationNickName;
		let groupId = req.body.groupId;
		let groupName = req.body.groupName;
		let headPic = req.body.headPic;

		if (!groupId || !operationNickName) {
			return next(new BadRequestError('groupId and operationNickName is need'));
		}

		if (!groupName && !headPic) {
			return next(new BadRequestError('groupName or headPic is need'));
		}

		let groupInfo = await UserModel.getGroupInfo(groupId);
		if (!groupInfo || groupInfo.Count === 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '不存在该群'
				}
			})
		}

		//验证该用户是否有权限
		let ownUserId = groupInfo.Result[0].userId;
		if (ownUserId !== userId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '没有修改的权限'
				}
			})
		}

		let result = await UserModel.updateGroup(groupId, groupName, headPic);
		if (result.Code === 0) {
			if (groupName) {
				//往群聊发送通知
				let content = {"message": `${operationNickName} 修改群名称为 ${groupName}`, "extra": "updateGroupName"};
				let publish = util.promisify(Message.group.publish);
				await publish(req.session.user._Id, groupId, 'RC:InfoNtf', JSON.stringify(content));
			}

			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: true,
					failed_message: '',
					success_message: '修改成功',
				}
			})
		}

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: false,
				failed_message: '修改失败',
				success_message: '',
			}
		})
	} catch (err) {
		next(err);
	}
};

//退出群
exports.quitGroup = async function (req, res, next) {
	try {
		let isMy = req.body.isMy;
		let userId = req.body.userId;
		let groupId = req.body.groupId;
		let nicknames = req.body.nicknames;
		let operationNickName = req.body.operationNickName;

		if (!isMy || !groupId || !nicknames || !operationNickName) {
			return next(new BadRequestError('isMy and groupId and nicknames and operationNickName is need'));
		}

		// if (userId) {
		// 	userId = userId.split(',').length > 1 ? userId.split(',') : userId.split(',')[0];
		// }

		if (isMy === 'true') {
			userId = req.session.user._Id;
		} else {
			userId = userId.split(',');
		}

		let content;
		if (isMy === 'true') {
			content = {
				operatorUserId: req.session.user._Id,
				operation: "Quit",
				data: {
					"operatorNickname": operationNickName,
					"targetUserIds": [userId],
					"targetUserDisplayNames": [nicknames],
					"newCreatorId": null
				},
				message: "退出群组",
				extra: "quit"
			}
		} else {
			content = {
				operatorUserId: req.session.user._Id,
				operation: "Kicked",
				data: {
					"operatorNickname": operationNickName,
					"targetUserIds": userId,
					"targetUserDisplayNames": nicknames.split(',')
				},
				message: "移出群成员",
				extra: "quit"
			}
		}
		let publish = util.promisify(Message.group.publish);
		await publish(req.session.user._Id, groupId, 'RC:GrpNtf', JSON.stringify(content));

		let boo = false;
		let quit = util.promisify(Group.quit);
		if (Array.isArray(userId)) {
			//批量退出
			let result = await quit(userId, groupId);

			if (JSON.parse(result).code === 200) {
				for (let id of userId) {
					await UserModel.delUserFromGroup(id, groupId);
				}
				boo = true;
			}
		} else {
			let result = await quit(userId, groupId);

			if (JSON.parse(result).code === 200) {
				await UserModel.delUserFromGroup(userId, groupId);
				boo = true;
			}
		}

		if (boo) {
			return res.json({
				flag: '0000', /**/
				msg: '',
				result: {
					ok: true,
					failed_message: '',
					success_message: '退群成功'
				}
			});
		}
		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: false,
				failed_message: '退群失败',
				success_message: ''
			}
		});

	} catch (err) {
		next(err);
	}
};

//解散群
exports.dismissGroup = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let groupId = req.query.groupId;
		let operationNickName = req.query.operationNickName;

		if (!groupId || !operationNickName) {
			return next(new BadRequestError('groupId and operationNickName is need'));
		}

		let groupInfo = await UserModel.getGroupInfo(groupId);
		if (!groupInfo || groupInfo.Count === 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '群不存在'
				}
			});
		}

		//验证该用户是否有权限解散该群
		let ownUserId = groupInfo.Result[0].userId;
		if (ownUserId !== userId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '没有解散该群的权限'
				}
			});
		}

		let content = {
			operatorUserId: req.session.user._Id,
			operation: "Dismiss",
			data: {"operatorNickname": operationNickName},
			message: "移出群成员",
			extra: "dismiss"
		};
		let publish = util.promisify(Message.group.publish);
		await publish(req.session.user._Id, groupId, 'RC:GrpNtf', JSON.stringify(content));

		//融云上操作
		let dismiss = util.promisify(Group.dismiss);
		let result = await dismiss(userId, groupId);

		if (JSON.parse(result).code !== 200) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '解散群失败'
				}
			});
		}
		await UserModel.delGroup(groupId);


		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '解散成功'
			}
		})
	} catch (err) {
		next(err);
	}
};

//修改在群中的昵称
exports.updateMyGroupNickname = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let groupId = req.body.groupId;
		let nickname = req.body.nickname;

		if (!groupId || !nickname) {
			return next(new BadRequestError('groupId is need'));
		}

		let result = await UserModel.updateGroupNickname(userId, groupId, nickname);

		if (!result) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '修改昵称失败'
				}
			});
		}

		return res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '修改成功'
			}
		});
	} catch (err) {
		next(err);
	}
};