/**
 * Created by liqp on 2017/11/23.
 */
const seckill = require('seckill');
const redpack = require('../../lib/redpack');
const UserModel = require('../../model/rongyun/user');
const RedpackModel = require('../../model/redpack/index');
const crypto = require('crypto');
const util = require('util');

//查询用户余额
exports.getAmount = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let table = req.session.user._TableName;

		let userInfo = await UserModel.getUserInfoForId(table, userId);

		if (userInfo.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '用户不存在',
					success_message: ''
				}
			})
		}

		let amount = userInfo.Result[0].amount;

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				amount: Number(amount)
			}
		});
	} catch (err){
	    next(err);
	}
};

//发红包
exports.sendRedPack = async function (req, res, next) {
	try {
		let userId = req.session.user._Id;
		let table = req.session.user._TableName;
	    let money = req.body.money;  //单位为元
	    let num = ~~req.body.number;
		let password = req.body.password;
	    let notes = req.body.notes;

	    if (!money || !num || !password || !notes) {
	        return next(new BadRequestError('notes and money and number and password is need'));
	    }

	    if (money*100 < 1) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '红包金额最小为0.01元',
					success_message: ''
				}
			})
	    }

	    if (String(num).indexOf('.') >= 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '个数应该为整数',
					success_message: ''
				}
			})
	    }

		if (money*100/num < 1) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '每个红包最小金额为0.01元',
					success_message: ''
				}
			})
		}

	    if (!userId) {
	        return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '用户不存在',
					success_message: ''
				}
			})
	    }

	    //密码校验
	    // let userPwd = crypto.createHash('sha256').update(password).digest('hex');
	    let checkPwd = await RedpackModel.checkPWD(userId, table === 'show_member' ? 1 : 0, password);
		if (checkPwd.Code !== 0 || checkPwd.Result.errorCode !== 0) {
			console.error(checkPwd);
			let failed = '接口错误';
			if (checkPwd.Result.errorMessage === 'Please try again later!') {
				failed = '请两小时以后再试'
			}
			if (checkPwd.Result.errorMessage === 'wrong password!') {
				failed = '密码错误'
			}
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: failed,
					success_message: ''
				}
			});
		}

		//拆分红包并且生成红包，但是此时红包还未生效
	    let redPacks = redpack.split(num, money*100);
		//判断生成的是否有负数
		let boo = false;
		redPacks.forEach(function (item) {
			if (item < 0) {
			    boo = true;
			}
		});
		if (boo) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '发送红包失败',
					success_message: ''
				}
			})
		}

		//调接口生成红包
	    let redpackId = await RedpackModel.createRedPack(userId, table, num, money*100, notes, redPacks);
	    if (!redpackId) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '发送红包失败',
					success_message: ''
				}
			})
	    }

	    // 调扣款接口
		let charge = await RedpackModel.redPackCharge(userId, money, table === 'show_member' ? 1 : 0, redpackId);
		if (charge.Code !== 0 || charge.Result.errorCode !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '发送红包失败!',
					success_message: ''
				}
			});
		}

		// //让红包生效
		// let updateResult = await RedpackModel.updateRedPackStatus(redpackId);
		//
	    // if (updateResult.Code !== 0) {
	    //     return  res.json({
			// 	flag: '0000',
			// 	msg: '',
			// 	result: {
			// 		ok: false,
			// 		failed_message: '发送红包失败!!',
			// 		success_message: ''
			// 	}
			// })
	    // }

	    let option = {
			startTime: new Date(),
			endTime: new Date().setSeconds(new Date().getSeconds()+86370),
			limit: 1,
		};
	    let add = util.promisify(seckill.addForTime);
		await add(redpackId, num, option);
	    res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				redpackId: redpackId
			}
		})

	} catch (err){
	    next(err)
	}
};

//领红包
exports.receiveRedPack = async function (req, res, next) {
	try {
	    let userId = req.session.user._Id;
		let userType = req.session.user._TableName === 'show_member' ? 1 : 0;
		let redPackId = req.body.redpackId;
		let redPackHead = req.body.redpackHead;

		if (!redPackId) {
			return next(new BadRequestError('redpackId is need'));
		}

		let result = await RedpackModel.getRemainNumber(redPackId);

		if (result.Code !== 0) {
		    return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '红包不存在',
					success_message: '',
					redpackHead: redPackHead,
				}
			})
		}

		if (result.Result[0].remainNumber < 1) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '抢完了',
					success_message: '',
					redpackHead: redPackHead,
				}
			})
		}

		if (new Date(result.Result[0].endTime) <= new Date()) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '红包已失效',
					success_message: '',
					redpackHead: redPackHead,
				}
			})
		}

		//调取redis进行事物操作
		let receive = util.promisify(seckill.getRedPack);
		let redisResult = await receive(redPackId, userId);
		if (redisResult.msg !== '完成') {
		    return res.json({
				flag: '0000',
				message: '',
				result: {
					ok: false,
					failed_message: redisResult.msg,
					success_message: '',
					redpackHead: redPackHead,
				}
			})
		}

		let sort = redisResult.num;
		let sendUserId = result.Result[0].userId;
		let sendUserType = result.Result[0].userRef._TableName === 'show_member' ? 1 : 0;

		//调接口领取红包
		let receiveResult = await RedpackModel.receiveRed(redPackId, sendUserId, sendUserType, userId, userType, sort);
		if (!redisResult) {
			return res.json({
				flag: '0000',
				message: '',
				result: {
					ok: false,
					failed_message: '领取红包失败，请重试',
					success_message: '',
					redpackHead: redPackHead,
				}
			})
		}
		//获取红包领取详情
		let receiveInfo = await RedpackModel.redPackInfo(redPackId);

		let list = [];
		if (receiveInfo.Code === 0) {
			receiveInfo.Result.forEach(function (info) {
				list.push({
					userId: info.userId,
					avatar: info.userRef._Object.headpic,
					nickname: info.userRef._Object.nickname,
					money: Math.round(info.money)/100,
					time: new Date(info.remitteeTime).getTime(),
					self: info.userId === userId,
					redpackHead: redPackHead,
					best: info.best,
				})
			});
		}

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				money: ~~receiveResult /100,
				time: new Date().getTime(),
				redpackHead: redPackHead,
				receiveInfo: list,
			}
		})
	} catch (err){
	    next(err)
	}
};

//获取红包领取详情
exports.getRedPackReceiveInfo = async function (req, res, next) {
	try {
		let redPackId = req.body.redpackId;
		let userId = req.session.user._Id;
		let redPackHead = req.body.redpackHead;

		if (!redPackId || !redPackHead) {
			return next(new BadRequestError('redpackId and redPackHead is need'));
		}

		let result = await RedpackModel.redPackInfo(redPackId);

		if (result.Code !== 0) {
			return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: '获取数据失败',
					success_message: ''
				}
			})
		}

		let list = [];

		result.Result.forEach(function (info) {
			list.push({
				userId: info.userId,
				avatar: info.userRef._Object.headpic,
				nickname: info.userRef._Object.nickname,
				money: Math.round(info.money)/100,
				time: new Date(info.remitteeTime).getTime(),
				self: info.userId === userId,
				redpackHead: redPackHead,
				best: info.best,
			})
		});

		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',
				success_message: '',
				list: list
			}
		})
	} catch (err){
		next(err)
	}
};

//检测用户是否设置二次密码
exports.checkSafePWD = async function (req, res, next) {
	try {
		if (!req.session.user._Object.safepwd) {
		    return res.json({
				flag: '0000',
				msg: '',
				result: {
					ok: false,
					failed_message: 'please set safe password'
				}
			})
		}
		res.json({
			flag: '0000',
			msg: '',
			result: {
				ok: true,
				failed_message: '',

			}
		})
	} catch (err){
		next(err)
	}
};
