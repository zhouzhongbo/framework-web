/**
 * Created by liqp on 2017/11/10.
 */
const rongyun = require('../../controller/rongyun');
const agent = require('../../controller/rongyun/agent');

exports.map = function (app) {
	app.get('/token', rongyun.getToken);		//获取融云token 留
	app.get('/user', rongyun.getUserInfo);		//获取用户信息
	app.post('/user/add', rongyun.inviteUserToUser);	//发送好友邀请  留

	app.post('/user/add/deal', rongyun.createUserToUserRelation);	//用户和用户处理好友邀请  删
	app.post('/user/trader/deal', rongyun.createTraderToUserRelation);	//添加商家和用户为好友  删

	app.get('/friends', rongyun.getFriends);	//获取好友列表 删
	app.delete('/friends', rongyun.delFriend);	//删除好友  删
	app.put('/nickname', rongyun.updateNickname);	//修改好友昵称  删

	app.get('/groups', rongyun.getGroups);			//获取群列表  删
	app.put('/group', rongyun.updateGroupInfo);		//修改群信息
	app.post('/group', rongyun.createGroup);		//创建群
	app.delete('/group', rongyun.dismissGroup);		//解散群
	app.get('/group', rongyun.getGroupInfo);		//获取群信息  删

	app.put('/group/notes', rongyun.updateGroupNote);		//修改群公告
	app.put('/group/nickname', rongyun.updateMyGroupNickname);		//修改自己在群中的昵称

	app.post('/group/user', rongyun.addGroup);		//添加用户到群
	app.post('/group/user/delete', rongyun.quitGroup);	//退出群


	app.post('/agent', agent.addAgent);

	//创建红包
	//领取红包
};