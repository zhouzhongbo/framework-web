/**
 * Created by liqp on 2017/11/17.
 */
const upload = require('../../controller/common/upload');

exports.map = function (app) {
	app.post('/upload', upload.formUpload);
};