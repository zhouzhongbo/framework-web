/**
 * Created by liqp on 2017/11/23.
 */
const redpack = require('../../controller/redpack');

exports.map = function (app) {
	app.get('/amount', redpack.getAmount);		//查询用户余额
	app.post('/redpack', redpack.sendRedPack);		//创建红包
	app.put('/redpack', redpack.receiveRedPack);		//领取红包
	app.put('/redpack/info', redpack.getRedPackReceiveInfo);		//领取红包

	app.get('/check/password', redpack.checkSafePWD);
	//创建红包
	//领取红包
};