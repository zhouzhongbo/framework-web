/**
 * Created by liqp on 2017/11/10.
 */
const object = require('./lib/object').DroiObject;
const file = require('./lib/file').DroiFile;
const user = require('./lib/user').DroiUser;
const config = require('../config').droi;

let OBJECT_CLIENT = new object(config.appid, config.key);
let FILE_CLIENT = new file(config.appid, config.key);
let USER_CLIENT = new user(config.appid, config.key);

exports.OBJECT_CLIENT = OBJECT_CLIENT;
exports.FILE_CLIENT = FILE_CLIENT;
exports.USER_CLIENT = USER_CLIENT;