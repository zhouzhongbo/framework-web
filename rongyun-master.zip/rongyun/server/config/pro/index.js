/**
 * Created by liqp on 2017/11/10.
 */

module.exports =  {
	/*
	 * @desc mysql 配置参数
	 * */
	mysql: {
		host: 'localhost',
		port: 6379,
		user: 'username',
		password: 'password',
		database: 'database'
	},
	/*
	 * @desc droibass 配置参数
	 * */
	droi: {
		appid:  'ypktmbzhDQzRokWzw6W5e2BvBRrtmOL8lQAA3nkH',
		key: 'L3fD_bmEFQb3HxiMHvQNNR4QnkOIWTd4aUc6XjLpk--eeJE9sy5_yhMPFN6R9BkZ',

		// appid: 'ypktmbzhDQzRokWzw6W5e2BvBRrtmOL8lQAA3nkH',
		// key: 'xzoY71yLXldEnE-Es0nO2niWDBf_3DryJ37RzaYVDAv9hhjRrpw26dKsjUkngv-B'
	}
};
