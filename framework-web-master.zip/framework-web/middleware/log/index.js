/**
 * Created by liqp on 2017/11/10.
 */
module.exports = function () {
	return function (req, res, next) {
		let start = Date.now();
		let end = res.end;

		res.end = function () {
			logger.info(req.method, req.path, Date.now() - start, new Date());
			end.apply(res, arguments);
		};

		next();
	};
};