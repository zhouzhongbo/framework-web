/**
 * @author logoli on 2017/11/10
 * @copyright
 * @desc
 */

/**
 * 对session参数进行处理
 * */
module.exports = function () {
	return function (req, res, next) {

		req.session = {};

		let token = req.get('token');

		token = token ? token.trim() : null;

		//没有token未登录,根据业务修改未登录操作
		if(!token){
			return next();
		}

		/*
		 * @desc 用token换session进行后续操作
		 * */
		next();
	}
};