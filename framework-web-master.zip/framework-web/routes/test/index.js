/**
 * Created by liqp on 2017/11/10.
 */
const test = require('../../controller/test');

exports.map = function (app) {
	app.get('/', test.home)
};