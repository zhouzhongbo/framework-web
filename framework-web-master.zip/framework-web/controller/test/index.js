/**
 * Created by liqp on 2017/11/10.
 * @接收客户端的数据进行校验等操作后通过调用model层提供的数据操作方法来进行业务逻辑的处理，得到结果后返回客户端
 */

exports.home = async function (req, res, next) {
	res.render('index', { title: 'Express' });
};