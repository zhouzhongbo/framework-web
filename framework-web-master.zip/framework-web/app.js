const express = require('express');
const path = require('path');
const favicon = require('serve-favicon');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const io = require('socket.io');

//重写app方法使其自动捕获async/await中的错误
const extend = require('./lib/extend/app').extend();

const config = require('./config');
const logger = require('./lib/logger');
const error = require('./lib/error');
const errorHandler = require('./middleware/error/index');

const log = logger(config.log);

const app = express();
//设置全局变量
global.logger = log;
global.HttpError = error.HttpError;
global.BadRequestError = error.BadRequestError;
global.UnauthorizedError = error.UnauthorizedError;
global.NotFoundError = error.NotFoundError;
global.InternalServerError = error.InternalServerError;

//设置模板引擎
app.set('views', path.join(__dirname, 'views'));
app.engine('.html', require('express-art-template'));
app.set('view options', config.template);
app.set('view engine', 'html');

app.set('port', config.server.port.http);
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'static')));

//日志记录
const apilog = require('./middleware/log');
app.use(apilog());

//route
const socket = require('./routes/socket');			//引入socket的路由
const test = require('./routes/test');

socket.map(app);									//注册socket的页面路由
test.map(app);

//传入socket的参数和路由信息
app.socket = {
	io: io,
	routers: [socket]
};

//error
app.use(errorHandler.notFoundHandler());
app.use(errorHandler.serverErrorHandler());

module.exports = app;
