/**
 * Created by liqp on 2017/11/10.
 */

module.exports =  {
	/*
	 * @desc mysql 配置参数
	 * */
	mysql: {
		host: 'localhost',
		port: 6379,
		user: 'username',
		password: 'password',
		database: 'database'
	}
};
