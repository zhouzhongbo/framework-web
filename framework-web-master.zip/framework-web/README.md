# express-web framework

## 文件夹说明
1. config --- 这里是整个项目的各种基本配置，分开发环境和生产环境
2. controller --- 这里是负责接收客户端参数进行业务逻辑处理的方法
3. lib --- 整个项目的一些基础服务包，如日志处理，错误类型定义等
4. middleware --- 一些中间件，包含错误处理，日志打印，分页参数计算，session管理等
5. model --- 进行数据的操作，负责数据的增删改查等方法
6. routes --- 所有的路由在此进行注册
7. server --- 封装一些驱动创建数据模型等底层服务，如数据库，消息队列等
8. static --- web页面所需要的静态文件
9. views --- html代码

## 约定

1. 层级调用关系：app ——> routes ——> controller ——> model ——> server;
2. 项目禁止同层互相调用，禁止跨层调用
3. 模板引擎为art-template(https://aui.github.io/art-template/zh-cn/docs/syntax.html)
4. 如需使用async/await请node版本一定要 >=8.9.0

## socket使用说明
1. 本框架使用的是socket.io来实现的；
2. socket的路由注册在app.socket.routes中，router中socket路由注册名为mapSocket
3. 业务逻辑统一在controller中处理

-----------------